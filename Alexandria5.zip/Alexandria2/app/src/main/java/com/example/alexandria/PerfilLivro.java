package com.example.alexandria;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class PerfilLivro extends AppCompatActivity {

    TextView titulo;
    ImageView capa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil_livro);

        titulo = findViewById(R.id.tituloPerfil); 
        capa = findViewById(R.id.capaPerfil);

        Intent intent =  getIntent();
        titulo.setText(intent.getStringExtra("titulo"));
        capa.setImageResource(intent.getIntExtra("capa", 0));


    }
}
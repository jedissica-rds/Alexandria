package com.example.alexandria.home_fragments;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ListAdapter;
import com.example.alexandria.Cadastro_Livros_Publicos;
import com.example.alexandria.MainActivity;
import com.example.alexandria.PerfilLivro;
import com.example.alexandria.R;
import com.example.alexandria.adapter.CustomAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class Fragment_Livros extends Fragment {

    GridView gv;
    String[] titulos = {"Fernando Pessoa"};
    int[] capas = {R.drawable.imagem_teste};


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View rootView = inflater.inflate(R.layout.fragment__livros, null);

        gv= rootView.findViewById(R.id.grid_view);

        CustomAdapter adapter = new CustomAdapter(getActivity(), titulos, capas );
        gv.setAdapter(adapter);

        gv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getContext(), PerfilLivro.class);
                intent.putExtra("titulo", titulos[position]);
                intent.putExtra("capa", capas[position]);
                startActivity(intent);
            }
        });

        return rootView;
    }
}
package com.example.alexandria.control;

import java.util.ArrayList;
import java.util.List;

public class LivroController {

    private int proxCodigo;
    private final List<Livro> acervo;
    private final List<String> titulosLivro;
    private final List<String> autorLivro;

    private static String[] arrayTitulo;
    private static String[] arrayAutor;

    private static LivroController instancia = null;

    private LivroController(){
        acervo = new ArrayList<>();
        titulosLivro = new ArrayList<>();
        autorLivro = new ArrayList<>();
        proxCodigo = 1;
    }

    public int getProxCodigo(){
        return proxCodigo;
    }

    public static LivroController getInstancia(){
        if (instancia == null)
            instancia = new LivroController();
        return instancia;
    }

    public void cadastrar(Livro livro){
        livro.setCodigo(proxCodigo);
        boolean resultado = acervo.add(livro);
        if (resultado)
            proxCodigo += 1;

    }

    public void cadastrarTitulos(Livro livro){
        livro.setCodigo(proxCodigo);
        boolean resultado = titulosLivro.add(livro.titulo);
        if (resultado)
            proxCodigo += 1;

    }

    public void cadastrarAutor(Livro livro){
        livro.setCodigo(proxCodigo);
        boolean resultado = autorLivro.add(livro.autor);
        if (resultado)
            proxCodigo += 1;

    }

    public void titulosToArray(Livro livro) {
        arrayTitulo = (String[]) titulosLivro.toArray();
    }

    public void autoresToArray(Livro livro) {
        arrayAutor = (String[]) autorLivro.toArray();
    }

    public boolean alterar(Livro funcionario){
        for (int i = 0; i < acervo.size(); i++) {
            if (funcionario.getCodigo()==acervo.get(i).getCodigo()){
                acervo.set(i, funcionario);
                return true;
            }
        }
        return false;
    }

    public int remover(Livro funcionario){
        int cont = 0;
        for (int i = 0; i < acervo.size(); i++) {
            if (funcionario.getCodigo()==acervo.get(i).getCodigo()){
                acervo.remove(i);
                cont += 1;
            }
        }
        return cont;
    }

    public List<Livro> buscarTodos(){
        return new ArrayList<>(acervo);
    }

    public Livro buscarPorPosicao(int posicao){
        return acervo.get(posicao);
    }

    public Livro buscarPorcodigo(int codigo){

        for (Livro funcionario : acervo){
            if (funcionario.getCodigo()==codigo)
                return funcionario;
        }
        return null;
    }
}
